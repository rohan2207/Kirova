import React from 'react';
import styled from 'styled-components';
import { useAuth } from '../context/AuthContext';

const PageContainer = styled.div`
  padding: 80px 40px;
`;

const Title = styled.h1`
  font-size: 2.5rem;
  margin-bottom: 40px;
`;

const DashboardPage = () => {
  const { currentUser } = useAuth();
  
  return (
    <PageContainer>
      <Title>Dashboard</Title>
      <p>Welcome, {currentUser?.email}! This is your dashboard.</p>
      <p>Your personalized grocery savings information will appear here.</p>
    </PageContainer>
  );
};

export default DashboardPage;
