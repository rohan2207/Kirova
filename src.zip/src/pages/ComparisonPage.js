import React from 'react';
import styled from 'styled-components';

const PageContainer = styled.div`
  padding: 80px 40px;
`;

const Title = styled.h1`
  font-size: 2.5rem;
  margin-bottom: 40px;
`;

const ComparisonPage = () => {
  return (
    <PageContainer>
      <Title>Compare Grocery Prices</Title>
      <p>Enter your grocery list and we'll find the cheapest store near you.</p>
      
      {/* Placeholder for comparison feature */}
      <div style={{ marginTop: '30px', padding: '20px', backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
        <p>Grocery comparison tool will appear here.</p>
      </div>
    </PageContainer>
  );
};

export default ComparisonPage;
