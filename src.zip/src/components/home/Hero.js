import React from 'react';
import styled, { keyframes } from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Button from '../common/Button';

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const HeroContainer = styled.div`
  background-color: ${props => props.theme.colors.primaryDark};
  position: relative;
  overflow: hidden;
  display: flex;
  min-height: 600px;
  
  @media (max-width: 992px) {
    flex-direction: column;
  }
`;

const HeroContent = styled.div`
  flex: 1;
  padding: 80px 40px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  max-width: 600px;
  animation: ${fadeIn} 1s ease-out;
  
  @media (max-width: 768px) {
    padding: 60px 20px;
    text-align: center;
    align-items: center;
  }
`;

const PhoneDisplay = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
  animation: ${fadeIn} 1s ease-out 0.3s both;
  
  @media (max-width: 992px) {
    padding: 0 20px 40px;
  }
`;

const AppMockup = styled.div`
  position: relative;
  width: 280px;
  height: 560px;
  background-color: ${props => props.theme.colors.white};
  border-radius: 30px;
  box-shadow: ${props => props.theme.shadows.large};
  padding: 12px;
  overflow: hidden;
  transform: perspective(800px) rotateY(-15deg) rotateX(5deg);
  border: 8px solid #333;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 120px;
    height: 20px;
    background-color: #333;
    border-radius: 0 0 10px 10px;
  }
`;

const AppContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  padding: 20px;
  background: #f9f9f9;
  border-radius: 18px;
`;

const LogoContainer = styled.div`
  width: 80%;
  max-width: 250px;
  aspect-ratio: 1 / 1;
  margin: 0 auto;
`;

const Heading = styled.h1`
  font-size: 4rem;
  font-weight: 800;
  color: ${props => props.theme.colors.white};
  margin-bottom: 24px;
  line-height: 1.1;
  text-transform: uppercase;
  position: relative;
  
  &::after {
    content: '';
    position: absolute;
    bottom: -12px;
    left: 0;
    width: 80px;
    height: 4px;
    background-color: ${props => props.theme.colors.secondary};
    border-radius: 2px;
  }
  
  @media (max-width: 768px) {
    font-size: 2.8rem;
    
    &::after {
      left: 50%;
      transform: translateX(-50%);
    }
  }
`;

const SubHeading = styled.p`
  font-size: 1.25rem;
  margin-bottom: 32px;
  color: ${props => props.theme.colors.white};
  opacity: 0.9;
  
  @media (max-width: 768px) {
    font-size: 1.1rem;
  }
`;

const CtaButton = styled.button`
  background-color: ${props => props.theme.colors.secondary};
  color: ${props => props.theme.colors.white};
  border: none;
  border-radius: ${props => props.theme.borderRadius.pill};
  padding: 16px 36px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all ${props => props.theme.transitions.default};
  align-self: flex-start;
  box-shadow: ${props => props.theme.shadows.medium};
  
  &:hover {
    background-color: #e59718; /* Darker shade of secondary */
    transform: translateY(-3px);
    box-shadow: ${props => props.theme.shadows.large};
  }
  
  @media (max-width: 768px) {
    align-self: center;
  }
`;

const LeafGraphic = styled.div`
  position: absolute;
  background-color: ${props => props.theme.colors.accent};
  opacity: 0.1;
  border-radius: 50%;
  z-index: 0;
  
  &.leaf1 {
    width: 300px;
    height: 300px;
    bottom: -150px;
    left: -150px;
  }
  
  &.leaf2 {
    width: 200px;
    height: 200px;
    top: -100px;
    right: 20%;
  }
`;

const AnimatedLeaf = styled.div`
  position: absolute;
  width: 80px;
  height: 80px;
  background-color: ${props => props.theme.colors.primary};
  opacity: 0.2;
  border-radius: 50% 0 50% 50%;
  transform: rotate(45deg);
  animation: float 8s infinite ease-in-out;
  
  &.leaf1 {
    top: 15%;
    right: 10%;
    animation-delay: 0s;
    width: 60px;
    height: 60px;
  }
  
  &.leaf2 {
    bottom: 20%;
    left: 5%;
    animation-delay: 2s;
    width: 40px;
    height: 40px;
  }
  
  &.leaf3 {
    top: 30%;
    left: 15%;
    animation-delay: 4s;
    width: 50px;
    height: 50px;
  }
  
  @keyframes float {
    0% { transform: rotate(45deg) translate(0, 0); }
    50% { transform: rotate(45deg) translate(15px, 15px); }
    100% { transform: rotate(45deg) translate(0, 0); }
  }
`;

const Hero = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  
  const handleGetStarted = () => {
    if (currentUser) {
      navigate('/compare');
    } else {
      navigate('/login', { state: { from: { pathname: '/compare' } } });
    }
  };
  
  return (
    <HeroContainer>
      <LeafGraphic className="leaf1" />
      <LeafGraphic className="leaf2" />
      <AnimatedLeaf className="leaf1" />
      <AnimatedLeaf className="leaf2" />
      <AnimatedLeaf className="leaf3" />
      
      <HeroContent>
        <Heading>Save More. Waste Less.</Heading>
        <SubHeading>
          Kirova helps you compare prices across stores and build the cheapest cart near you.
        </SubHeading>
        
        <CtaButton onClick={handleGetStarted}>
          Start Comparing
        </CtaButton>
      </HeroContent>
      
      <PhoneDisplay>
        <AppMockup>
          <AppContent>
            <LogoContainer>
              <svg width="100%" height="100%" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                {/* K-Human hybrid - large version for app display */}
                <circle cx="22" cy="20" r="10" fill="#71B340" /> {/* Head */}
                <rect x="19" y="30" width="6" height="45" rx="3" fill="#71B340" /> {/* Body */}
                <path d="M22 45 L50 20" stroke="#71B340" strokeWidth="7" strokeLinecap="round" /> {/* Upper diagonal */}
                <path d="M22 45 L50 75" stroke="#71B340" strokeWidth="7" strokeLinecap="round" /> {/* Lower diagonal */}
                
                {/* Shopping cart */}
                <path d="M60 75 L90 75 L85 40 L65 40 Z" fill="none" stroke="#71B340" strokeWidth="4" /> {/* Cart body */}
                <path d="M65 40 L60 25 L55 25" stroke="#71B340" strokeWidth="4" strokeLinecap="round" /> {/* Handle */}
                <line x1="70" y1="40" x2="70" y2="75" stroke="#71B340" strokeWidth="2" /> {/* Divider 1 */}
                <line x1="80" y1="40" x2="80" y2="75" stroke="#71B340" strokeWidth="2" /> {/* Divider 2 */}
                <circle cx="70" cy="85" r="5" fill="white" stroke="#71B340" strokeWidth="3" /> {/* Left wheel */}
                <circle cx="85" cy="85" r="5" fill="white" stroke="#71B340" strokeWidth="3" /> {/* Right wheel */}
              </svg>
            </LogoContainer>
          </AppContent>
        </AppMockup>
      </PhoneDisplay>
    </HeroContainer>
  );
};

export default Hero;