import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Button from './Button';

const NavContainer = styled.nav`
  background-color: ${props => props.theme?.colors?.primaryDark || '#2F4A22'};
  box-shadow: ${props => props.theme?.shadows?.small || '0 2px 8px rgba(0, 0, 0, 0.08)'};
  position: sticky;
  top: 0;
  z-index: 1000;
  backdrop-filter: blur(8px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
`;

const NavContent = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 40px;
  max-width: 1200px;
  margin: 0 auto;
  
  @media (max-width: 768px) {
    padding: 12px 20px;
  }
`;

// This is now a regular div, not a Link
const LogoContainer = styled.div`
  display: flex;
  align-items: center;
`;

// The Link now wraps everything
const LogoLink = styled(Link)`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme?.colors?.white || '#FFFFFF'};
  text-decoration: none;
  display: flex;
  align-items: center;
  letter-spacing: -1px;
  
  @media (max-width: 576px) {
    font-size: 1.7rem;
  }
`;

const LogoSvgWrapper = styled.div`
  height: 60px;
  width: 60px;
  margin-right: -10px;
  
  @media (max-width: 576px) {
    height: 48px;
    width: 48px;
  }
`;

const LogoSvg = styled.svg`
  height: 100%;
  width: 100%;
  
  path, rect, circle, line {
    stroke: ${props => props.theme?.colors?.white || '#FFFFFF'};
    fill: ${props => (props.fill ? props.theme?.colors?.white || '#FFFFFF' : 'none')};
  }
  
  circle {
    fill: ${props => props.theme?.colors?.white || '#FFFFFF'};
  }
`;

const TextSpan = styled.span`
  font-size: 2.2rem;
  
  @media (max-width: 576px) {
    font-size: 1.8rem;
  }
`;

const MenuItems = styled.div`
  display: flex;
  align-items: center;
  
  @media (max-width: 768px) {
    display: ${props => (props.isOpen ? 'flex' : 'none')};
    flex-direction: column;
    position: absolute;
    top: 80px;
    left: 0;
    right: 0;
    background-color: ${props => props.theme?.colors?.primaryDark || '#2F4A22'};
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
    padding: 20px;
    gap: 15px;
    align-items: flex-start;
  }
`;

const MenuItem = styled(Link)`
  margin-right: 24px;
  color: ${props => props.theme?.colors?.white || '#FFFFFF'};
  text-decoration: none;
  font-weight: 500;
  position: relative;
  
  &:after {
    content: '';
    position: absolute;
    width: 0;
    height: 2px;
    bottom: -4px;
    left: 0;
    background-color: ${props => props.theme?.colors?.white || '#FFFFFF'};
    transition: width 0.3s ease;
  }
  
  &:hover, &.active {
    color: ${props => props.theme?.colors?.secondary || '#F9A826'};
    
    &:after {
      width: 100%;
      background-color: ${props => props.theme?.colors?.secondary || '#F9A826'};
    }
  }
  
  @media (max-width: 768px) {
    margin-right: 0;
    margin-bottom: 16px;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 10px;
`;

const MobileMenuToggle = styled.button`
  display: none;
  background: none;
  border: none;
  font-size: 1rem;
  cursor: pointer;
  color: ${props => props.theme?.colors?.white || '#FFFFFF'};
  
  @media (max-width: 768px) {
    display: block;
  }
`;

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { currentUser, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Close mobile menu on location change
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);
  
  const handleLogout = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      console.error('Failed to log out', error);
    }
  };
  
  const handleLogin = () => {
    navigate('/login');
  };
  
  const handleSignup = () => {
    navigate('/signup');
  };
  
  // Function to check if a path is active
  const isActive = (path) => {
    return location.pathname === path;
  };
  
  return (
    <NavContainer>
      <NavContent>
        <LogoContainer>
          {/* The Link now wraps both the SVG and the text */}
          <LogoLink to="/">
            <LogoSvgWrapper>
              <LogoSvg viewBox="0 0 100 50" xmlns="http://www.w3.org/2000/svg">
                {/* K-Human hybrid */}
                <circle cx="12" cy="10" r="5" fill="white" /> {/* Head */}
                <rect x="10" y="15" width="4" height="23" rx="2" fill="white" /> {/* Body */}
                <path d="M12 22 L24 12" stroke="white" strokeWidth="4" strokeLinecap="round" /> {/* Upper diagonal */}
                <path d="M12 22 L24 35" stroke="white" strokeWidth="4" strokeLinecap="round" /> {/* Lower diagonal */}
                
                {/* Shopping cart */}
                <path d="M35 35 L55 35 L52 20 L38 20 Z" fill="none" stroke="white" strokeWidth="2.5" /> {/* Cart body */}
                <path d="M38 20 L35 14 L32 14" stroke="white" strokeWidth="2.5" strokeLinecap="round" /> {/* Handle */}
                <line x1="41" y1="20" x2="41" y2="35" stroke="white" strokeWidth="1.5" /> {/* Divider 1 */}
                <line x1="46" y1="20" x2="46" y2="35" stroke="white" strokeWidth="1.5" /> {/* Divider 2 */}
                <circle cx="42" cy="40" r="2.5" fill="none" stroke="white" strokeWidth="1.5" /> {/* Left wheel */}
                <circle cx="52" cy="40" r="2.5" fill="none" stroke="white" strokeWidth="1.5" /> {/* Right wheel */}
              </LogoSvg>
            </LogoSvgWrapper>
            <TextSpan>Kirova</TextSpan>
          </LogoLink>
        </LogoContainer>
        
        <MobileMenuToggle 
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? 'Close' : 'Menu'}
        </MobileMenuToggle>
        
        <MenuItems isOpen={isMenuOpen}>
          <MenuItem to="/" className={isActive('/') ? 'active' : ''}>Home</MenuItem>
          <MenuItem to="/how-it-works" className={isActive('/how-it-works') ? 'active' : ''}>How It Works</MenuItem>
          
          {currentUser ? (
            <>
              <MenuItem to="/dashboard" className={isActive('/dashboard') ? 'active' : ''}>Dashboard</MenuItem>
              <MenuItem to="/compare" className={isActive('/compare') ? 'active' : ''}>Compare Prices</MenuItem>
              <Button onClick={handleLogout} variant="light">Log Out</Button>
            </>
          ) : (
            <ButtonGroup>
              <Button onClick={handleLogin} variant="outline" color="white">Log In</Button>
              <Button onClick={handleSignup} variant="light">Sign Up</Button>
            </ButtonGroup>
          )}
        </MenuItems>
      </NavContent>
    </NavContainer>
  );
};

export default Navbar;